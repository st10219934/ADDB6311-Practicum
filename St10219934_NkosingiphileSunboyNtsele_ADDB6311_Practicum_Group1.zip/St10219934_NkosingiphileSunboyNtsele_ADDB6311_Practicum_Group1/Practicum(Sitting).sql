CREATE TABLE instructor (
ins_id int NOT NULL PRIMARY KEY, 
ins_fname varchar(50),
ins_sname varchar(50), 
ins_contact NUMBER(11),
ins_level number (3));

INSERT INTO instructor(ins_id, ins_fname, ins_sname, ins_contact, ins_level)
VALUES (101 ,'James', 'Willis',0843569851,7);
				

INSERT INTO instructor(ins_id, ins_fname, ins_sname, ins_contact, ins_level)
VALUES (102 ,'Sam', 'Wait',0763698521,2);
				

INSERT INTO instructor(ins_id, ins_fname, ins_sname, ins_contact, ins_level)
VALUES (103 ,'Sally','Gumede', 0786598521,8);
				

INSERT INTO instructor(ins_id, ins_fname, ins_sname, ins_contact, ins_level)
VALUES (104 ,'Bob', 'Du Preez',0796369857,3);
				

INSERT INTO instructor(ins_id, ins_fname, ins_sname, ins_contact, ins_level)
VALUES (105 ,'Simon', 'Jones',0826598741,9);
				



CREATE TABLE customer(
cust_id varchar(50)NOT NULL PRIMARY KEY, 
cust_fname varchar(50),
cust_sname varchar(50), 
cust_address varchar(50),
cust_contact NUMBER(11));

INSERT INTO customer(cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C115' ,'Heinrich', ' Willis','3 Main Road', 0821253659);
	

INSERT INTO customer(cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C116' ,'David', ' Watson','13 Cape Road', 0769658547);
				

INSERT INTO customer(cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C117' ,'Waldo', ' Smith','3 Mountain Road', 0863256574);
				

INSERT INTO customer(cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C118' ,'Alex', ' Hanson','8 Circle Road', 0762356587);
				

INSERT INTO customer(cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C119' ,'Kuhle', ' Bitterhout','15 Main Road', 0821235258);
				

INSERT INTO customer(cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C120' ,'Thando', ' Zolani','88 Summer Road', 0847541254);
				

INSERT INTO customer(cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C121' ,'Philip', ' Jackson','3 Long Road', 0745556658);
				

INSERT INTO customer(cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C122' ,'Sarah', ' Jones','7 Sea Road', 0814745745);
				

INSERT INTO customer(cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C123' ,'Catherine', ' Howard','31 Lake Side Road	', 0822232521);
			


CREATE TABLE dive ( 
dive_id int NOT NULL PRIMARY KEY,
dive_name VARCHAR(50),
dive_duration VARCHAR(50),
dive_location VARCHAR(50),
dive_exp_level VARCHAR(50),
dive_cost number (5));

INSERT INTO dive(dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (550,'Shark Dive','3 hours','Shark Point ',8,500);
			
INSERT INTO dive(dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (551,'Coral Dive','1 hour','	Break Point  ',7,300);
	 	
INSERT INTO dive(dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (552,'Wave Crescent','2 hours','Ship wreck ally ',3,800);
	 		 		
INSERT INTO dive(dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (553,'Underwater Exploration','1 hour','Coral ally',2,250);
	 	 		
INSERT INTO dive(dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (554,'Underwater Adventure','3 hours','Sandy Beach ',3,750);
	 		
INSERT INTO dive(dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (555	,'Deep Blue Ocean ','30 minutes','Lazy Waves',2,120);
		 		   
INSERT INTO dive(dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (556,'Rough Seas','1 hour','Pipe ',9,700);
	 			
INSERT INTO dive(dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (557,'White Water','2 hours','Drifts ',5,200);
	 		
INSERT INTO dive(dive_id, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (558,'Current Adventure','2 hours','Rock Lands',3,150);
	 	 		
	 				
CREATE TABLE dive_event(
dive_event_id varchar(50),
dive_event_date DATE,
dive_participants NUMBER(10),
ins_id INT,
cust_id varchar(50),
dive_id int);

ALTER TABLE dive_event
ADD FOREIGN KEY (cust_id) REFERENCES customer(cust_id);

ALTER TABLE dive_event
ADD FOREIGN KEY (ins_id) REFERENCES instructor(ins_id);

ALTER TABLE dive_event
ADD FOREIGN KEY (dive_id) REFERENCES dive(dive_id);

INSERT INTO dive_event(dive_event_id, dive_event_date, dive_participants, ins_id, cust_id, dive_id)
VALUES ('de_101' , TO_DATE('15-JUL-17','DD-MM-YY'),  5,103 , 'C115', 558 );
	
INSERT INTO dive_event(dive_event_id, dive_event_date, dive_participants, ins_id, cust_id, dive_id)
VALUES ('de_102' , TO_DATE('16-JUL-17','DD-MM-YY'),  7,102 , 'C117', 555 );
				
INSERT INTO dive_event(dive_event_id, dive_event_date, dive_participants, ins_id, cust_id, dive_id)
VALUES ('de_103' , TO_DATE('18-JUL-17','DD-MM-YY'),  8,104 , 'C118', 552 );
			
INSERT INTO dive_event(dive_event_id, dive_event_date, dive_participants, ins_id, cust_id, dive_id)
VALUES ('de_104' , TO_DATE('19-JUL-17','DD-MM-YY'),  3,101 , 'C119', 551 );
		
INSERT INTO dive_event(dive_event_id, dive_event_date, dive_participants, ins_id, cust_id, dive_id)
VALUES ('de_105' , TO_DATE('21-JUL-17','DD-MM-YY'),  5,104 , 'C121', 558 );
		
INSERT INTO dive_event(dive_event_id, dive_event_date, dive_participants, ins_id, cust_id, dive_id)
VALUES ('de_106' , TO_DATE('22-JUL-17','DD-MM-YY'),  8,105 , 'C120', 556 );
		
INSERT INTO dive_event(dive_event_id, dive_event_date, dive_participants, ins_id, cust_id, dive_id)
VALUES ('de_107' , TO_DATE('25-JUL-17','DD-MM-YY'),  10,105 , 'C115', 554 );
			
INSERT INTO dive_event(dive_event_id, dive_event_date, dive_participants, ins_id, cust_id, dive_id)
VALUES ('de_108' , TO_DATE('27-JUL-17','DD-MM-YY'),  5,101 , 'C122', 552 );
				
INSERT INTO dive_event(dive_event_id, dive_event_date, dive_participants, ins_id, cust_id, dive_id)
VALUES ('de_109' , TO_DATE('28-JUL-17','DD-MM-YY'), 3,102 , 'C123', 553 );
				
                

--Question 2
--An administrator user
CREATE USER C##Admin IDENTIFIED BY Admin345;
GRANT CONNECT TO C##Admin;
GRANT CREATE SESSION TO C##Admin;
GRANT ALL PRIVILEGES to C##Admin

--general user of the system
CREATE USER C##User IDENTIFIED BY User884;
GRANT CONNECT TO C##User;
GRANT CREATE SESSION TO C##User;
GRANT INSERT ANY TABLE TO C##User;

--Question 3
SELECT instructor.ins_fname, instructor.ins_sname, customer.cust_fname, customer.cust_sname, dive.dive_location, dive_participants
from dive_event
inner join customer on customer.cust_id = dive_event.cust_id
inner join instructor on instructor.ins_id = dive_event.ins_id
inner join dive on dive.dive_id = dive_event.dive_id
where dive_event.dive_participants BETWEEN 8 AND 10;

--Question 4
SET SERVEROUTPUT ON;
DECLARE 
    Divenames dive.dive_name%TYPE;
   datesAllocated dive_event.dive_event_date%TYPE;
    participants dive_event.dive_participants%TYPE;
BEGIN
    FOR records IN (
        SELECT c.dive_id, v.dive_event_date, v.dive_participants
        FROM dive_event v
        INNER JOIN dive c ON v.dive_id = c.dive_id
        WHERE v.dive_participants >=10
    )
    LOOP
        Divenames := records.dive_id;
        datesAllocated := records.dive_event_date;
        participants := records.dive_participants;
        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || Divenames);
    DBMS_OUTPUT.PUT_LINE('Stock  Type: ' || datesAllocated);
    DBMS_OUTPUT.PUT_LINE('Sales Amount: R ' || participants);
    DBMS_OUTPUT.PUT_LINE('------------------------------');
    END LOOP;
END;


--Question 5
SET SERVEROUTPUT ON;
DECLARE 
    customerFnames customer.cust_fname%TYPE;
    customerSnameS customer.cust_sname%TYPE;
    eventNames dive.dive_name%TYPE;
    participants dive_event.dive_participants%TYPE;
    diveCosts dive.dive_cost%TYPE;
    instructorsRequired NUMBER;
  
   
BEGIN
    FOR record IN (
        SELECT c.cust_fname, c.cust_sname, k.dive_name,k.dive_cost , ku.dive_participants
        FROM dive_event ku
        INNER JOIN customer c ON ku.cust_id =c.cust_id
        INNER JOIN dive k ON ku.dive_id = k.dive_id
        where k.dive_cost >500
       
    )
    LOOP
        customerFnames := record.cust_fname;
        customerSnames := record.cust_sname;
        eventNames := record.dive_name;
        diveCosts := record.dive_cost;
        participants := record.dive_participants;
    
       
       IF participants <= 4 THEN
          instructorsRequired :=1;
       ELSIF participants BETWEEN 5 AND 7 THEN
          instructorsRequired :=2; 
       ELSIF participants >= 8 THEN
          instructorsRequired := 3; 
       ELSE 
          instructorsRequired := participants;
       END IF;
          
       DBMS_OUTPUT.PUT_LINE('CUSTOMERS FULL NAME: ' || customerFnames ||customerSnames);
       DBMS_OUTPUT.PUT_LINE('DIVE NAME: ' || eventNames);
       DBMS_OUTPUT.PUT_LINE('PARTICIPANTS: ' || participants);
       DBMS_OUTPUT.PUT_LINE('STATUS: ' || instructorsRequired);
       DBMS_OUTPUT.PUT_LINE('------------------------------');
    END LOOP;
END;
/

--QUESTION 6
CREATE VIEW Vw_Dive_Event
AS
SELECT instructor.ins_id, customer.cust_id, customer.cust_address, dive.dive_duration, dive_event.dive_event_date
FROM dive_event
JOIN instructor ON  dive_event.ins_id = instructor.ins_id
JOIN customer ON dive_event.cust_id =customer.cust_id
JOIN dive ON dive_event.dive_id = dive.dive_id
where dive_event.dive_event_date < TO_DATE('19-JUL-17','DD-MM-YY')

select * from Vw_Dive_Event;


--QUESTION 7
SET SERVEROUTPUT ON;
create or Replace trigger New_Dive_Event
Before Insert on dive_event
For Each Row 
Enable
Begin
 if :NEW.dive_participants <= 0 then
    RAISE_APPLICATION_ERROR(-20001,'The participans are less than 0 ');
 elsif :NEW.dive_participants >= 20 then
    RAISE_APPLICATION_ERROR(-20002,' The participants are more than 20');
 else 
  RAISE_APPLICATION_ERROR(-20003,' Participants inserted correct');
 end if;
 end;
 
  
--testing the trigger for more than 20 participants
Begin 
    insert into dive_event ( dive_participants)Values(20);
     DBMS_OUTPUT.PUT_LINE('Insert successful');
Exception 
    When others then 
    DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
End;
/

--testing the trigger for more than 0 participants
Begin 
    insert into dive_event ( dive_participants)Values(0);
     DBMS_OUTPUT.PUT_LINE('Insert successful');
Exception 
    When others then 
    DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
End;
/
--testing the trigger for more than 5 participants
Begin 
    insert into dive_event ( dive_participants)Values(5);
     DBMS_OUTPUT.PUT_LINE('Insert successful');
Exception 
    When others then 
    DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
End;
/


--QUESTION 8
CREATE OR REPLACE PROCEDURE sp_customer_details(p_customerId IN NUMBER, diveDate date)
AS
  CURSOR c_customer IS
    SELECT customer.cust_fname, dive.dive_name, dive_event_date
    FROM dive_event
    join customer on dive_event.cust_id = customer.cust_id
    join dive on dive_event.dive_id = dive.dive_id
    WHERE customer.cust_id = p_customerId AND dive_event.dive_event_date = diveDate ;

  v_customer c_customer%ROWTYPE;
BEGIN
  OPEN c_customer;
  LOOP
    FETCH c_customer INTO v_customer;
    EXIT WHEN c_customer%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE('Customer ID: ' || v_customer.cust_fname ||
                         ', First Name: ' || v_customer.dive_name);
  END LOOP;
  CLOSE c_customer;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('No customers found with that id ' || p_customerId);
     DBMS_OUTPUT.PUT_LINE('No date found for the particular day ' || diveDate);
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('An error occurred: ' || SQLERRM);
END;
/

--QUESTION 9
Create or Replace Function Dive_function (p_cust_id in VARCHAR2)
return varchar2
is results varchar2(4000);
Begin
--Concatenate the query results into a single string
SELECT 'Customer Name: ' || customer.cust_fname || CHR(10) ||
           'Dive Name: ' || dive.dive_name || CHR(10) ||
           'Dive Cost: ' || dive.dive_cost || CHR(10) ||
           'Dive Date: ' || dive_event.dive_event_date
    INTO results
    from dive_event
    JOIN dive ON  dive_event.dive_id = dive.dive_id
    JOIN customer ON dive_event.cust_id =customer.cust_id
    where customer.cust_id = p_cust_id;
    
Return results;

Exception
    When NO_DATA_FOUND Then
    --handle the case 
    Return 'No Sales found for the given customer id';
    When Others Then
    Return 'An unexpected error occured:'||SQLERRM;

End;
/
   
DECLARE
    results VARCHAR2(4000);
BEGIN
    -- Call the function with a specific customer ID
    results := Dive_function('C115'); 
    
    -- Display the result
    DBMS_OUTPUT.PUT_LINE(results);

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('An error occurred: ' || SQLERRM);
END;
/

--QUESTION 10
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.addb6311;
import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class Addb6311 {

    public static void main(String[] args) {
        String name = JOptionPane.showInputDialog("IT Gear dealer \n"
                + "***************************************************\n"
                + "\n"
                + "1 to sp_customer_details\n"
                + "2 to fn_Dive_Adjustments");
                
    }
}







